package org.wit.placemark.models.json

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import org.jetbrains.anko.AnkoLogger
import org.wit.placemark.helpers.exists
import org.wit.placemark.helpers.read
import org.wit.placemark.helpers.write
import org.wit.placemark.models.PlacemarkModel
import org.wit.placemark.models.PlacemarkStore
import java.util.*


val JSON_FILE = "placemark.json"
val gsonBuilder = GsonBuilder().setPrettyPrinting().create()
val listType = object : TypeToken<java.util.ArrayList<PlacemarkModel>>() {}.type

fun generateRandomId(): Long{
  return Random().nextLong()
}

class PlacemarkJSONStore : PlacemarkStore, AnkoLogger{

  val context: Context
  var placemarks = mutableListOf<PlacemarkModel>()

  constructor(context: Context){
    this.context = context
    if (exists(context, JSON_FILE)){
      deserialize()
    }
  }

  override suspend fun findAll(): MutableList<PlacemarkModel> {
    return placemarks
  }

  override suspend fun findById(id:Long) : PlacemarkModel? {
    return placemarks.find { it.id == id }
  }

  override suspend fun create(placemark: PlacemarkModel) {
    placemark.id = generateRandomId()
    placemarks.add(placemark)
    serialize()
  }


  override suspend fun update(placemark: PlacemarkModel) {
    var foundPlacemark: PlacemarkModel? = placemarks.find { p -> p.id == placemark.id}
    if (foundPlacemark != null){
      foundPlacemark.title = placemark.title
      foundPlacemark.description = placemark.description
      foundPlacemark.image = placemark.image
      foundPlacemark.location = placemark.location
      serialize()
    }
  }

  override suspend fun delete(placemark: PlacemarkModel) {
    placemarks.remove(placemark)
    serialize()
  }

  override fun clear() {
    placemarks.clear()
  }

  private fun serialize() {
    val jsonString = gsonBuilder.toJson(placemarks, listType)
    write(context, JSON_FILE, jsonString)
  }

  private fun deserialize() {
    val jsonString = read(context, JSON_FILE)
    placemarks = Gson().fromJson(jsonString, listType)
  }
}