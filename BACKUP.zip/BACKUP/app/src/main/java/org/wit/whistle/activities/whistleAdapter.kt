package org.wit.whistle.activities

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.card_whistle.view.*
import org.wit.whistle.R
import org.wit.whistle.models.whistleModel

interface whistleListener {
  fun onwhistleClick(whistle: whistleModel)
}

class whistleAdapter constructor(private var whistle: List<whistleModel>,
                                   private val listener: whistleListener) : RecyclerView.Adapter<whistleAdapter.MainHolder>() {

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainHolder {
    return MainHolder(LayoutInflater.from(parent?.context).inflate(R.layout.card_whistle, parent, false))
  }

  override fun onBindViewHolder(holder: MainHolder, position: Int) {
    val whistle = whistle[holder.adapterPosition]
    holder.bind(whistle, listener)
  }

  override fun getItemCount(): Int = whistle.size

  class MainHolder constructor(itemView: View) : RecyclerView.ViewHolder(itemView) {

    fun bind(whistle: whistleModel, listener: whistleListener) {
      itemView.whistleTitle.text = whistle.title
      itemView.description.text = whistle.description
      itemView.setOnClickListener { listener.onwhistleClick(whistle) }
    }
  }
}