package org.wit.whistle.models

import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info

var lastId = 0L

internal fun getId(): Long {
  return lastId++
}

class whistleMemStore : whistleStore, AnkoLogger {

  val whistles = ArrayList<whistleModel>()

  override fun findAll(): List<whistleModel> {
    return whistles
  }

  override fun create(whistle: whistleModel) {
    whistle.id = getId()
    whistles.add(whistle)
    logAll()
  }

  override fun update(whistle: whistleModel) {
    var foundwhistle: whistleModel? = whistles.find { p -> p.id == whistle.id }
    if (foundwhistle != null) {
      foundwhistle.title = whistle.title
      foundwhistle.description = whistle.description
    }
  }

  internal fun logAll() {
    whistles.forEach { info("${it}") }
  }
}