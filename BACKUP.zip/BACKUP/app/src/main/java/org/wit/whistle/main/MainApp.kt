package org.wit.whistle.main

import android.app.Application
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import org.wit.whistle.models.whistleMemStore

class MainApp : Application(), AnkoLogger {

  val whistles = whistleMemStore()

  override fun onCreate() {
    super.onCreate()
    info("whistle message started")
  }
}