package org.wit.whistle.activities

import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_whistle_list.*
import kotlinx.android.synthetic.main.card_whistle.view.*
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.startActivityForResult
import org.wit.whistle.R
import org.wit.whistle.main.MainApp
import org.wit.whistle.models.whistleModel

class whistleListActivity : AppCompatActivity(), whistleListener {

  lateinit var app: MainApp

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_whistle_list)
    app = application as MainApp
    toolbar.title = title
    setSupportActionBar(toolbar)

    val layoutManager = LinearLayoutManager(this)
    recyclerView.layoutManager = layoutManager
    recyclerView.adapter = whistleAdapter(app.whistles.findAll(), this)}

  override fun onCreateOptionsMenu(menu: Menu?): Boolean {
    menuInflater.inflate(R.menu.menu_main, menu)
    return super.onCreateOptionsMenu(menu)}

  override fun onOptionsItemSelected(item: MenuItem?): Boolean {
    when (item?.itemId) {R.id.item_add -> startActivityForResult<whistleActivity>(0)}
    return super.onOptionsItemSelected(item)}

  override fun onwhistleClick(whistle: whistleModel) {
    startActivityForResult(intentFor<whistleActivity>().putExtra("whistle_edit", whistle), AppCompatActivity.RESULT_OK)}}