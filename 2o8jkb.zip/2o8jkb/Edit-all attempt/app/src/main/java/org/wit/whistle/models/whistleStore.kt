package org.wit.whistle.models

interface whistleStore {
  fun findAll(): List<whistleModel>
  fun create(whistle: whistleModel)
  fun update(whistle: whistleModel)
}