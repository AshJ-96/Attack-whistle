# Okta Kotlin Android CRUD example

This is the source code for the Okta Kotlin Android CRUD tutorial.

## Setup

Go to each folder to see the `README.md` on setting up and running.
Make sure you run the server first and then the client.