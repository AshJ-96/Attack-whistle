package org.wit.whistle.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import kotlinx.android.synthetic.main.activity_whistle.*
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import org.jetbrains.anko.toast
import org.wit.whistle.R
import org.wit.whistle.main.MainApp
import org.wit.whistle.models.PlacemarkModel

class PlacemarkActivity : AppCompatActivity(), AnkoLogger {

  var whistle = PlacemarkModel()
  lateinit var app: MainApp

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_whistle)
    toolbarAdd.title = title
    setSupportActionBar(toolbarAdd)
    info("Placemark Activity started..")

    app = application as MainApp

    if (intent.hasExtra("whistle_edit")) {
      whistle = intent.extras?.getParcelable<PlacemarkModel>("whistle_edit")!!
      whistleTitle.setText(whistle.title)
      description.setText(whistle.description)
    }

    btnAdd.setOnClickListener() {
      whistle.title = whistleTitle.text.toString()
      whistle.description = description.text.toString()
      if (whistle.title.isNotEmpty()) {
        app.whistles.create(whistle.copy())
        info("add Button Pressed: $whistleTitle")
        setResult(AppCompatActivity.RESULT_OK)
        finish()
      } else {
        toast("Please Enter a title")
      }
    }
  }

  override fun onCreateOptionsMenu(menu: Menu?): Boolean {
    menuInflater.inflate(R.menu.menu_whistle, menu)
    return super.onCreateOptionsMenu(menu)
  }

  override fun onOptionsItemSelected(item: MenuItem?): Boolean {
    when (item?.itemId) {
      R.id.item_cancel -> {
        finish()
      }
    }
    return super.onOptionsItemSelected(item)
  }
}

