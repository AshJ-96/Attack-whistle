package org.wit.whistle.main

import android.app.Application
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import org.wit.whistle.models.PlacemarkMemStore

class MainApp : Application(), AnkoLogger {

  val whistles = PlacemarkMemStore()

  override fun onCreate() {
    super.onCreate()
    info("Placemark started")
  }
}