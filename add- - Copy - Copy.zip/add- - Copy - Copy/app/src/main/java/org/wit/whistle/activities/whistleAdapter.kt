package org.wit.whistle.activities

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.card_whistle.view.*
import org.wit.whistle.R
import org.wit.whistle.models.PlacemarkModel

interface PlacemarkListener {
  fun onPlacemarkClick(whistle: PlacemarkModel)
}

class PlacemarkAdapter constructor(private var whistles: List<PlacemarkModel>,
                                   private val listener: PlacemarkListener) : RecyclerView.Adapter<PlacemarkAdapter.MainHolder>() {

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainHolder {
    return MainHolder(LayoutInflater.from(parent?.context).inflate(R.layout.card_whistle, parent, false))
  }

  override fun onBindViewHolder(holder: MainHolder, position: Int) {
    val whistle = whistles[holder.adapterPosition]
    holder.bind(whistle, listener)
  }

  override fun getItemCount(): Int = whistles.size

  class MainHolder constructor(itemView: View) : RecyclerView.ViewHolder(itemView) {

    fun bind(whistle: PlacemarkModel, listener: PlacemarkListener) {
      itemView.whistleTitle.text = whistle.title
      itemView.description.text = whistle.description
      itemView.setOnClickListener { listener.onPlacemarkClick(whistle) }
    }
  }
}