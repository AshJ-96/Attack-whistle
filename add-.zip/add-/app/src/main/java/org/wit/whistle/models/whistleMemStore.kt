package org.wit.whistle.models

import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info

var lastId = 0L

internal fun getId(): Long {
  return lastId++
}

class PlacemarkMemStore : PlacemarkStore, AnkoLogger {

  val whistles = ArrayList<PlacemarkModel>()

  override fun findAll(): List<PlacemarkModel> {
    return whistles
  }

  override fun create(whistle: PlacemarkModel) {
    whistle.id = getId()
    whistles.add(whistle)
    logAll()
  }

  override fun update(whistle: PlacemarkModel) {
    var foundPlacemark: PlacemarkModel? = whistles.find { p -> p.id == whistle.id }
    if (foundPlacemark != null) {
      foundPlacemark.title = whistle.title
      foundPlacemark.description = whistle.description
    }
  }

  internal fun logAll() {
    whistles.forEach { info("${it}") }
  }
}