package org.wit.whistle.models

interface PlacemarkStore {
  fun findAll(): List<PlacemarkModel>
  fun create(whistle: PlacemarkModel)
  fun update(whistle: PlacemarkModel)
}